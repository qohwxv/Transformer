#!/usr/bin/env python3
"""Shared host-side utilities for the M8 retained-DDR dataset runner."""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from typing import Iterator


REPO_ROOT = Path(__file__).resolve().parents[4]
SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG = SCRIPT_DIR / "m8_session_config.json"
BOARD_LOCK = Path("/tmp/vit_m8_board.lock")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SERIAL_RE = re.compile(r"^[0-9A-Fa-f]{8,32}$")


class DatasetRunnerError(RuntimeError):
    """A fail-closed dataset runner error."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_repo_path(value: str, *, must_exist: bool = True) -> Path:
    raw = Path(value)
    resolved = (raw if raw.is_absolute() else REPO_ROOT / raw).resolve()
    try:
        resolved.relative_to(REPO_ROOT)
    except ValueError as error:
        raise DatasetRunnerError(f"Path escapes repository: {resolved}") from error
    if must_exist and not resolved.exists():
        raise DatasetRunnerError(f"Required path does not exist: {resolved}")
    return resolved


def relative_to_repo(path: Path) -> str:
    return path.resolve().relative_to(REPO_ROOT).as_posix()


def load_config(path: Path = DEFAULT_CONFIG) -> dict[str, object]:
    config_path = path.resolve()
    if not config_path.is_file():
        raise DatasetRunnerError(f"Config does not exist: {config_path}")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    required = {
        "schema",
        "identity",
        "boot_receipt",
        "cable_serial",
        "xsct",
        "hw_server_url",
        "sessions_root",
        "runs_root",
        "dataset_dir",
        "ground_truth",
        "poll_ms",
        "timeout_ms",
        "capture_outputs",
    }
    if set(config) != required:
        missing = sorted(required - set(config))
        extra = sorted(set(config) - required)
        raise DatasetRunnerError(f"Config key mismatch: missing={missing}, extra={extra}")
    if config["schema"] != "vit-m8-dataset-session-config-v1":
        raise DatasetRunnerError("Unsupported dataset session config schema")
    serial = str(config["cable_serial"])
    if not SERIAL_RE.fullmatch(serial):
        raise DatasetRunnerError("Config cable serial is not concrete")
    if config["capture_outputs"] not in {"all", "logits", "none"}:
        raise DatasetRunnerError("capture_outputs must be all, logits, or none")
    if int(config["poll_ms"]) < 10 or int(config["timeout_ms"]) <= 0:
        raise DatasetRunnerError("Invalid polling/timeout configuration")
    return config


def parse_record(path: Path) -> dict[str, str]:
    if not path.is_file():
        raise DatasetRunnerError(f"Record does not exist: {path}")
    values: dict[str, str] = {}
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise DatasetRunnerError(f"Invalid record line {line_number}: {path}")
        key, value = line.split("=", 1)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", key) or not value or key in values:
            raise DatasetRunnerError(f"Invalid/duplicate field {key!r}: {path}")
        values[key] = value
    return values


def write_record_atomic(path: Path, pairs: list[tuple[str, object]]) -> None:
    lines: list[str] = []
    seen: set[str] = set()
    for key, raw_value in pairs:
        value = str(raw_value)
        if (
            not re.fullmatch(r"[a-z][a-z0-9_]*", key)
            or key in seen
            or not value
            or "\n" in value
            or "\r" in value
        ):
            raise DatasetRunnerError(f"Invalid output record field: {key}")
        seen.add(key)
        lines.append(f"{key}={value}\n")
    atomic_write_text(path, "".join(lines))


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.tmp-", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def atomic_write_json(path: Path, value: object) -> None:
    atomic_write_text(path, json.dumps(value, indent=2, sort_keys=True) + "\n")


@contextlib.contextmanager
def exclusive_board_lock() -> Iterator[None]:
    BOARD_LOCK.parent.mkdir(parents=True, exist_ok=True)
    with BOARD_LOCK.open("a+", encoding="ascii") as stream:
        try:
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise DatasetRunnerError(
                "Board đang được một setup/test runner khác sử dụng"
            ) from error
        stream.seek(0)
        stream.truncate()
        stream.write(f"pid={os.getpid()}\n")
        stream.flush()
        try:
            yield
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)

