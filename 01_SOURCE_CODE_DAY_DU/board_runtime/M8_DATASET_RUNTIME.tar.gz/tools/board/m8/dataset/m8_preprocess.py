#!/usr/bin/env python3
"""Persistent, bit-contract-compatible image preprocessor for M8 batches."""

from __future__ import annotations

import hashlib
import json
import os
import struct
from pathlib import Path

from m8_dataset_common import REPO_ROOT, atomic_write_json, sha256_file


EXPECTED_WORDS = 150_528
EXPECTED_BYTES = EXPECTED_WORDS * 4
PROCESSOR_DIR = REPO_ROOT / "preprocessing/processor"


class M8Preprocessor:
    """Load the Hugging Face processor once and prepare many images."""

    def __init__(self) -> None:
        import torch.nn.functional as functional
        from transformers import AutoImageProcessor

        self._functional = functional
        self._processor = AutoImageProcessor.from_pretrained(
            PROCESSOR_DIR, local_files_only=True
        )
        digest = hashlib.sha256()
        for path in sorted(item for item in PROCESSOR_DIR.rglob("*") if item.is_file()):
            relative = path.relative_to(PROCESSOR_DIR).as_posix()
            digest.update(relative.encode("utf-8"))
            digest.update(b"\0")
            digest.update(bytes.fromhex(sha256_file(path)))
        self.processor_sha256 = digest.hexdigest()

    def prepare(self, image_path: Path, stage_dir: Path, ordinal: int) -> dict[str, object]:
        import numpy as np
        from PIL import Image

        source = image_path.resolve()
        stage_dir = stage_dir.resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        stage_dir.mkdir(parents=True, exist_ok=False)
        with Image.open(source) as decoded:
            decoded_size = [decoded.size[0], decoded.size[1]]
            rgb = decoded.convert("RGB")
        pixel_values = self._processor(images=rgb, return_tensors="pt")["pixel_values"]
        if tuple(pixel_values.shape) != (1, 3, 224, 224):
            raise ValueError(f"Unexpected processor output shape: {tuple(pixel_values.shape)}")
        patch_a = self._functional.unfold(
            pixel_values, kernel_size=(16, 16), stride=(16, 16)
        ).transpose(1, 2).contiguous()
        if tuple(patch_a.shape) != (1, 196, 768):
            raise ValueError(f"Unexpected patch tensor shape: {tuple(patch_a.shape)}")
        words = patch_a.cpu().numpy().astype("<f4", copy=False).reshape(-1).view("<u4")
        if words.size != EXPECTED_WORDS:
            raise ValueError(f"Unexpected prepared word count: {words.size}")
        payload = words.tobytes(order="C")
        if len(payload) != EXPECTED_BYTES:
            raise ValueError(f"Unexpected prepared byte count: {len(payload)}")

        output = stage_dir / "prepared_input.bin"
        temporary = stage_dir / ".prepared_input.bin.tmp"
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, output)
        source_sha256 = sha256_file(source)
        input_sha256 = hashlib.sha256(payload).hexdigest()
        first_word = struct.unpack_from("<I", payload, 0)[0]
        last_word = struct.unpack_from("<I", payload, len(payload) - 4)[0]
        try:
            source_display = source.relative_to(REPO_ROOT).as_posix()
        except ValueError:
            source_display = str(source)
        manifest = {
            "schema": "vit-m8-dataset-preprocess-v1",
            "image_ordinal": ordinal,
            "source_image": {
                "path": source_display,
                "sha256": source_sha256,
                "size_bytes": source.stat().st_size,
                "decoded_size": decoded_size,
            },
            "processor_sha256": self.processor_sha256,
            "tensor": {
                "shape": [1, 196, 768],
                "dtype": "IEEE754_BINARY32_RAW_BITS",
                "word_count": EXPECTED_WORDS,
                "byte_order": "LITTLE_ENDIAN",
                "layout": "patch_y,patch_x,channel,kernel_y,kernel_x",
            },
            "prepared_input": {
                "path": output.relative_to(REPO_ROOT).as_posix(),
                "size_bytes": EXPECTED_BYTES,
                "sha256": input_sha256,
                "first_word": f"0x{first_word:08X}",
                "last_word": f"0x{last_word:08X}",
            },
        }
        manifest_path = stage_dir / "preprocess_manifest.json"
        atomic_write_json(manifest_path, manifest)
        return manifest
