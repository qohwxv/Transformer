# Shared fail-closed helpers for the experimental M8 retained-DDR dataset runner.
# This file defines procedures only. It never connects to JTAG by itself.

proc m8_utc_now {} {
    return [clock format [clock seconds] -gmt true -format {%Y-%m-%dT%H:%M:%SZ}]
}
proc m8_log {message} { puts "[m8_utc_now] $message"; flush stdout }
proc m8_word_u32 {value} { return [expr {$value & 0xFFFFFFFF}] }
proc m8_word_hex {value} { return [format {0x%08X} [m8_word_u32 $value]] }
proc m8_sha256_file {path} {
    return [lindex [split [string trim [exec sha256sum -- $path]]] 0]
}

proc m8_parse_record {path} {
    if {![file isfile $path]} { error "record is missing: $path" }
    set channel [open $path r]
    fconfigure $channel -translation lf -encoding utf-8
    set values [dict create]
    set line_number 0
    set failed [catch {
        while {[gets $channel line] >= 0} {
            incr line_number
            set line [string trim $line]
            if {$line eq {} || [string match {#*} $line]} { continue }
            set separator [string first {=} $line]
            if {$separator <= 0} { error "record line $line_number is not key=value" }
            set key [string range $line 0 [expr {$separator - 1}]]
            set value [string range $line [expr {$separator + 1}] end]
            if {![regexp {^[a-z][a-z0-9_]*$} $key] || $value eq {} ||
                [dict exists $values $key]} {
                error "invalid/duplicate record field at line $line_number"
            }
            dict set values $key $value
        }
    } message options]
    close $channel
    if {$failed} { return -options $options $message }
    return $values
}

proc m8_require_record_keys {record keys label} {
    foreach key $keys {
        if {![dict exists $record $key] || [dict get $record $key] eq {}} {
            error "$label lacks mandatory key $key"
        }
    }
}

proc m8_write_record_exclusive {path pairs} {
    set channel [open $path {WRONLY CREAT EXCL}]
    fconfigure $channel -translation lf -encoding utf-8
    set failed [catch {
        foreach {key value} $pairs {
            if {![regexp {^[a-z][a-z0-9_]*$} $key] ||
                [string first "\n" $value] >= 0 || $value eq {}} {
                error "invalid output record field $key"
            }
            puts $channel "$key=$value"
        }
        flush $channel
    } message options]
    close $channel
    if {$failed} { catch {file delete -- $path}; return -options $options $message }
}

proc m8_resolve_repo_artifact {repo_root value} {
    if {[file pathtype $value] eq {absolute}} {
        set resolved [file normalize $value]
    } else {
        set resolved [file normalize [file join $repo_root $value]]
    }
    set prefix "[file normalize $repo_root]/"
    if {![string equal -length [string length $prefix] $resolved $prefix]} {
        error "artifact escapes repository: $resolved"
    }
    return $resolved
}

proc m8_validate_identity_before_jtag {repo_root identity boot_receipt} {
    set python [file join $repo_root .venv bin python]
    set validator [file join $repo_root tools board m8 m8_board_identity.py]
    if {![file executable $python] || ![file isfile $validator]} {
        error {M8 Python identity validator is unavailable}
    }
    set command [list $python $validator validate-boot \
        --repo-root $repo_root --identity $identity --boot-receipt $boot_receipt]
    set failed [catch {exec {*}$command 2>@1} output options]
    if {$output ne {}} { puts $output; flush stdout }
    if {$failed} { error {canonical M8 identity/boot validation failed before JTAG} }
}

proc m8_identity_artifact {identity repo_root prefix} {
    return [list [string toupper $prefix] \
        [m8_resolve_repo_artifact $repo_root [dict get $identity ${prefix}_path]] \
        [dict get $identity ${prefix}_size] \
        [dict get $identity ${prefix}_sha256]]
}

proc m8_verify_artifact {spec phase} {
    lassign $spec label path expected_size expected_hash
    if {![file isfile $path] || [file size $path] != $expected_size} {
        error "$phase: $label missing or size mismatch: $path"
    }
    set actual [m8_sha256_file $path]
    if {$actual ne $expected_hash} {
        error "$phase: $label SHA-256 mismatch: got $actual expected $expected_hash"
    }
    m8_log "ARTIFACT_REHASH phase=$phase label=$label size=$expected_size sha256=$actual path=$path"
}

proc m8_read_words {address count} {
    set values [mrd -force -value $address $count]
    if {[llength $values] != $count} {
        error [format {short memory read at 0x%08X: got %d expected %d} \
            $address [llength $values] $count]
    }
    return $values
}
proc m8_read_word {address} {
    return [m8_word_u32 [lindex [m8_read_words $address 1] 0]]
}
proc m8_write_word {address value} { mwr -force $address $value }
proc m8_assert_word {label actual expected} {
    if {[m8_word_u32 $actual] != [m8_word_u32 $expected]} {
        error "$label mismatch: got [m8_word_hex $actual], expected [m8_word_hex $expected]"
    }
    m8_log "PASS: $label = [m8_word_hex $actual]"
}
proc m8_read_counter64 {label low_address} {
    set low [m8_read_word $low_address]
    set high [m8_read_word [expr {$low_address + 4}]]
    set value [expr {($high << 32) | $low}]
    m8_log [format {PERF_COUNTER name=%s value=%s hex=0x%08X%08X} \
        $label $value $high $low]
    return $value
}

proc m8_require_dict_field {properties key label} {
    if {![dict exists $properties $key]} { error "$label lacks property $key" }
    return [dict get $properties $key]
}
proc m8_one_named_debug_target {properties exact_name} {
    set matches {}
    foreach item $properties {
        if {[dict exists $item name] && [dict get $item name] eq $exact_name} {
            lappend matches $item
        }
    }
    if {[llength $matches] != 1} {
        error "expected one debug target '$exact_name'; found [llength $matches]"
    }
    return [lindex $matches 0]
}
proc m8_one_apu_debug_target {properties} {
    set matches {}
    foreach item $properties {
        if {[dict exists $item name] &&
            ([dict get $item name] eq {APU} ||
             [dict get $item name] eq {APU (L2 Cache Reset)})} {
            lappend matches $item
        }
    }
    if {[llength $matches] != 1} { error {expected one canonical APU target} }
    return [lindex $matches 0]
}
proc m8_require_device_binding {item serial device node label} {
    if {[m8_require_dict_field $item jtag_cable_serial $label] ne $serial ||
        [m8_require_dict_field $item jtag_device_name $label] ne $device ||
        [m8_require_dict_field $item jtag_device_id $label] != $node} {
        error "$label is not bound to audited $device device"
    }
}

proc m8_audit_topology_properties {jtag_props debug_props serial require_pmu_exec} {
    set cables {}
    foreach item $jtag_props {
        if {[dict exists $item level] && [dict get $item level] == 0 &&
            [dict exists $item name] &&
            [string match {Digilent Genesys ZU - 5EV *} [dict get $item name]]} {
            lappend cables $item
        }
    }
    if {[llength $cables] != 1} { error {expected exactly one Genesys ZU-5EV cable} }
    set cable [lindex $cables 0]
    if {[m8_require_dict_field $cable jtag_cable_serial CABLE] ne $serial ||
        [m8_require_dict_field $cable is_open CABLE] != 1 ||
        [m8_require_dict_field $cable is_active CABLE] != 1} {
        error {Genesys cable serial/open/active identity mismatch}
    }
    set fpga_matches {}; set dap_matches {}
    foreach item $jtag_props {
        if {[dict exists $item name] && [dict get $item name] eq {xczu5} &&
            [dict exists $item is_fpga] && [dict get $item is_fpga] == 1} {
            lappend fpga_matches $item
        }
        if {[dict exists $item name] && [dict get $item name] eq {arm_dap}} {
            lappend dap_matches $item
        }
    }
    if {[llength $fpga_matches] != 1 || [llength $dap_matches] != 1} {
        error {expected one xczu5 and one arm_dap JTAG node}
    }
    set fpga [lindex $fpga_matches 0]; set dap [lindex $dap_matches 0]
    set fpga_node [m8_require_dict_field $fpga node_id FPGA]
    set dap_node [m8_require_dict_field $dap node_id DAP]
    if {[m8_require_dict_field $fpga jtag_cable_serial FPGA] ne $serial ||
        ![regexp -nocase {^(0x)?04720093$} [m8_require_dict_field $fpga idcode FPGA]] ||
        [m8_require_dict_field $fpga irlen FPGA] != 12} {
        error {xczu5 FPGA JTAG identity mismatch}
    }
    if {[m8_require_dict_field $dap jtag_cable_serial DAP] ne $serial ||
        ![regexp -nocase {^(0x)?5ba00477$} [m8_require_dict_field $dap idcode DAP]] ||
        [m8_require_dict_field $dap irlen DAP] != 4 || $dap_node == $fpga_node} {
        error {arm_dap JTAG identity mismatch}
    }
    set ps [m8_one_named_debug_target $debug_props {PS TAP}]
    set pmu [m8_one_named_debug_target $debug_props PMU]
    set pl [m8_one_named_debug_target $debug_props PL]
    set psu [m8_one_named_debug_target $debug_props PSU]
    set apu [m8_one_apu_debug_target $debug_props]
    set a53 [m8_one_named_debug_target $debug_props {Cortex-A53 #0}]
    foreach {label item} [list PS_TAP $ps PMU_GATEWAY $pmu PL $pl] {
        m8_require_device_binding $item $serial xczu5 $fpga_node $label
    }
    foreach {label item} [list PSU $psu APU $apu A53_0 $a53] {
        m8_require_device_binding $item $serial arm_dap $dap_node $label
    }
    set ps_ctx [m8_require_dict_field $ps target_ctx PS_TAP]
    set psu_ctx [m8_require_dict_field $psu target_ctx PSU]
    set apu_ctx [m8_require_dict_field $apu target_ctx APU]
    if {[m8_require_dict_field $ps parent_ctx PS_TAP] ne {} ||
        [m8_require_dict_field $psu parent_ctx PSU] ne {} ||
        [m8_require_dict_field $pmu parent_ctx PMU] ne $ps_ctx ||
        [m8_require_dict_field $pl parent_ctx PL] ne $ps_ctx ||
        [m8_require_dict_field $apu parent_ctx APU] ne $psu_ctx ||
        [m8_require_dict_field $a53 parent_ctx A53] ne $apu_ctx} {
        error {ZynqMP debug-target hierarchy mismatch}
    }
    set result [dict create fpga_node_id $fpga_node dap_node_id $dap_node \
        psu [dict get $psu target_id] pl [dict get $pl target_id] \
        a53_0 [dict get $a53 target_id]]
    if {$require_pmu_exec} {
        set exec [m8_one_named_debug_target $debug_props {MicroBlaze PMU}]
        m8_require_device_binding $exec $serial xczu5 $fpga_node PMU_EXEC
        if {[m8_require_dict_field $exec parent_ctx PMU_EXEC] ne
            [m8_require_dict_field $pmu target_ctx PMU]} {
            error {MicroBlaze PMU parent mismatch}
        }
        dict set result pmu_exec [dict get $exec target_id]
    }
    return $result
}

proc m8_audit_live_topology {serial require_pmu phase} {
    set result [m8_audit_topology_properties [jtag targets -target-properties] \
        [targets -target-properties] $serial $require_pmu]
    m8_log "JTAG_TOPOLOGY_PASS phase=$phase cable_serial=$serial fpga_node_id=[dict get $result fpga_node_id] dap_node_id=[dict get $result dap_node_id]"
    return $result
}
proc m8_select_target {topology key label} {
    if {![dict exists $topology $key]} { error "topology lacks $key" }
    targets [dict get $topology $key]
    m8_log "INFO: selected audited target $label id=[dict get $topology $key]"
}

proc m8_dump_words_hex {path base count} {
    set channel [open $path {WRONLY CREAT EXCL}]
    fconfigure $channel -translation lf -encoding ascii
    set failed [catch {
        for {set first 0} {$first < $count} {incr first 128} {
            set length [expr {min(128, $count - $first)}]
            foreach value [m8_read_words [expr {$base + 4 * $first}] $length] {
                puts $channel [format {%08x} [m8_word_u32 $value]]
            }
        }
    } message options]
    close $channel
    if {$failed} { return -options $options $message }
}

proc m8_write_m7_csv {path control_base} {
    set names {
        fp16_term_accepts fp16_disabled_term_accepts fp16_dot_start_cycles
        fp16_result_vector_cycles fp16_feeder_stall_cycles
        fp16_result_backpressure_cycles panel_load_active_cycles
        panel_compute_active_cycles panel_store_active_cycles
        panel_stage_union_cycles panel_load_compute_overlap_cycles
        panel_compute_store_overlap_cycles panel_load_store_overlap_cycles
        panel_three_way_overlap_cycles operand_bank_commits operand_bank_claims
        operand_bank_releases operand_bank_empty_wait_cycles
        operand_bank_full_wait_cycles operand_bank_max_occupancy
        result_fifo_enqueues result_fifo_dequeues result_fifo_max_occupancy
    }
    set channel [open $path {WRONLY CREAT EXCL}]
    fconfigure $channel -translation lf -encoding ascii
    puts $channel {index,name,value}
    for {set index 0} {$index < 23} {incr index} {
        set value [m8_read_counter64 [lindex $names $index] \
            [expr {$control_base + 0x830 + 8 * $index}]]
        puts $channel "$index,[lindex $names $index],$value"
    }
    close $channel
}
