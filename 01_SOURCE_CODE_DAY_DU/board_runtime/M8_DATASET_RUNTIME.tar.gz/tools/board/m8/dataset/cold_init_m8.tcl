# Cold, volatile JTAG initialization for one retained-DDR M8 dataset session.
# It programs boot/PL, initializes DDR, loads model/table once, configures M8,
# then exits with the board idle. It never starts an inference job.

if {[llength $argv] != 6} {
    puts stderr {Usage: xsct cold_init_m8.tcl <repo> <session-dir> <identity> <boot-receipt> <serial> <scratch-zero>}
    exit 2
}

set repo_root [file normalize [lindex $argv 0]]
set session_dir [file normalize [lindex $argv 1]]
set identity_path [file normalize [lindex $argv 2]]
set boot_path [file normalize [lindex $argv 3]]
set serial [string toupper [lindex $argv 4]]
set scratch_zero [file normalize [lindex $argv 5]]
set script_dir [file dirname [file normalize [info script]]]
source [file join $script_dir m8_dataset_common.tcl]

if {![file isdirectory $repo_root] || ![file isdirectory $session_dir] ||
    ![regexp {^[0-9A-F]{8,32}$} $serial]} {
    puts stderr {ERROR: invalid cold-init arguments}
    exit 2
}
set state_path [file join $session_dir session_state.txt]
if {[file exists $state_path]} {
    puts stderr {ERROR: session state already exists; refusing to overwrite}
    exit 2
}

set connected 0
set force_mem_enabled 0
set control_base 0xA0000000
set model_base 0x10000000
set input_base 0x24B00000
set table_base 0x25000000
set scratch_base 0x27000000
set session_marker_0 0x4D385345
set session_marker_1 0x5353494F

set failed [catch {
    m8_validate_identity_before_jtag $repo_root $identity_path $boot_path
    set identity [m8_parse_record $identity_path]
    set boot [m8_parse_record $boot_path]
    m8_require_record_keys $identity {
        profile expected_ip_id expected_ip_version execution_mode job_config
        bit_path bit_size bit_sha256 xsa_path xsa_size xsa_sha256
        model_path model_size model_sha256 table_path table_size table_sha256
    } IDENTITY
    m8_require_record_keys $boot {
        xsa_path xsa_size xsa_sha256 fsbl_path fsbl_size fsbl_sha256
        pmufw_path pmufw_size pmufw_sha256
    } BOOT
    if {[dict get $identity profile] ne {m8_v3_mode3_nongemm_nodsp_50mhz} ||
        [dict get $identity expected_ip_id] ne {0x5649544E} ||
        [dict get $identity expected_ip_version] ne {0x0001000D} ||
        [dict get $identity execution_mode] ne {3} ||
        [dict get $identity job_config] ne {0x00001D85}} {
        error {identity is not the exact M8 IP-v1.13 mode-3 candidate}
    }

    set bit_spec [m8_identity_artifact $identity $repo_root bit]
    set xsa_spec [m8_identity_artifact $identity $repo_root xsa]
    set model_spec [m8_identity_artifact $identity $repo_root model]
    set table_spec [m8_identity_artifact $identity $repo_root table]
    set fsbl_path [m8_resolve_repo_artifact $repo_root [dict get $boot fsbl_path]]
    set pmufw_path [m8_resolve_repo_artifact $repo_root [dict get $boot pmufw_path]]
    set fsbl_spec [list FSBL $fsbl_path [dict get $boot fsbl_size] [dict get $boot fsbl_sha256]]
    set pmufw_spec [list PMUFW $pmufw_path [dict get $boot pmufw_size] [dict get $boot pmufw_sha256]]
    set zero_spec [list SCRATCH_ZERO $scratch_zero 7962624 \
        4cf5f204c0583a572fa4310cc7b737f8e9862f2975e592dc7ea5849208ee29df]
    foreach spec [list $bit_spec $xsa_spec $model_spec $table_spec $fsbl_spec $pmufw_spec $zero_spec] {
        m8_verify_artifact $spec PRE_JTAG
    }
    m8_log {M8_DATASET_COLD_PREFLIGHT_PASS jtag=NOT_YET_TOUCHED}

    if {[info exists ::env(VIT_HW_SERVER_URL)] && $::env(VIT_HW_SERVER_URL) ne {}} {
        connect -url $::env(VIT_HW_SERVER_URL)
    } else {
        connect
    }
    set connected 1
    set topology [m8_audit_live_topology $serial 0 COLD_PRE_RESET]
    m8_select_target $topology psu PSU
    rst -system
    after 3000
    m8_log {PASS: system reset completed}

    set topology [m8_audit_live_topology $serial 0 COLD_POST_RESET]
    m8_select_target $topology psu PSU
    m8_write_word 0xFFCA0038 0x000001FF
    after 500
    m8_log {PASS: ZynqMP JTAG security gates opened}

    set topology [m8_audit_live_topology $serial 1 COLD_PRE_PMUFW]
    m8_select_target $topology pmu_exec {MicroBlaze PMU}
    m8_verify_artifact $pmufw_spec IMMEDIATE_PRE_PMUFW_DOW
    dow $pmufw_path
    con
    after 1000
    m8_log {PASS: PMUFW downloaded and started}

    set topology [m8_audit_live_topology $serial 1 COLD_PRE_BIT]
    m8_select_target $topology pl PL
    m8_verify_artifact $bit_spec IMMEDIATE_PRE_BIT_PROGRAM
    fpga -file [lindex $bit_spec 1]
    after 1500
    m8_log {PASS: exact M8 BIT programmed}

    set topology [m8_audit_live_topology $serial 1 COLD_PRE_FSBL]
    m8_select_target $topology a53_0 {Cortex-A53 #0}
    m8_verify_artifact $fsbl_spec IMMEDIATE_PRE_FSBL_DOW
    rst -processor -stop -clear-registers
    dow $fsbl_path
    con
    after 15000
    catch {stop}
    m8_log {PASS: exact-XSA Genesys FSBL completed}
    configparams force-mem-accesses 1
    set force_mem_enabled 1

    m8_assert_word DDR_REG_FFD80060 [m8_read_word 0xFFD80060] 0
    m8_assert_word DDR_REG_FFD80044 [m8_read_word 0xFFD80044] 3
    set ddr_status [m8_read_word 0xFD070004]
    if {($ddr_status & 1) == 0} { error {DDR controller is not initialized} }
    m8_write_word 0x01000000 0x11111111
    m8_write_word 0x01004000 0x22222222
    m8_assert_word DDR_SMOKE_0 [m8_read_word 0x01000000] 0x11111111
    m8_assert_word DDR_SMOKE_1 [m8_read_word 0x01004000] 0x22222222

    m8_assert_word IP_ID [m8_read_word [expr {$control_base + 0x000}]] 0x5649544E
    m8_assert_word IP_VERSION [m8_read_word [expr {$control_base + 0x004}]] 0x0001000D
    m8_assert_word PERF_CAPABILITY [m8_read_word [expr {$control_base + 0x048}]] 0x0001001F
    m8_assert_word PROFILE_CAPABILITY2 [m8_read_word [expr {$control_base + 0x188}]] 0x00027FFF
    m8_assert_word M5_CAPABILITY [m8_read_word [expr {$control_base + 0x7C0}]] 0x01F21008
    m8_assert_word M7_CAPABILITY [m8_read_word [expr {$control_base + 0x810}]] 0x01FF0817
    m8_assert_word M7_GEOMETRY [m8_read_word [expr {$control_base + 0x824}]] 0x08100208
    m8_assert_word M7_BUFFER [m8_read_word [expr {$control_base + 0x828}]] 0x00080202
    m8_assert_word M7_NUMERIC [m8_read_word [expr {$control_base + 0x82C}]] 0x07C0D05D
    m8_assert_word NPU_IDLE [m8_read_word [expr {$control_base + 0x00C}]] 1

    m8_verify_artifact $model_spec IMMEDIATE_PRE_MODEL_DOW
    m8_log "LOAD_MODEL_START_UTC=[m8_utc_now]"
    dow -data [lindex $model_spec 1] $model_base
    m8_log "LOAD_MODEL_DONE_UTC=[m8_utc_now]"
    m8_assert_word MODEL_FIRST [m8_read_word $model_base] 0xA6FF2005
    m8_assert_word MODEL_LAST [m8_read_word 0x1A5A3BFC] 0x3E8209A8

    m8_verify_artifact $table_spec IMMEDIATE_PRE_TABLE_DOW
    dow -data [lindex $table_spec 1] $table_base
    set expected_header {
        0x4D544956 0x004C4254 0x00000003 0x00000080
        0x00000001 0x00000002 0x000000C8 0x00000040
        0x00000080 0x0000001F 0x00000080 0x00000000
        0x00003280 0x00000000 0x0528EAE8 0x00000000
        0x02968F00 0x00000000 0x0A5A3C00 0x00000000
    }
    set table_header [m8_read_words $table_base 20]
    for {set i 0} {$i < 20} {incr i} {
        m8_assert_word "MODEL_TABLE_HEADER_$i" [lindex $table_header $i] [lindex $expected_header $i]
    }

    set config {0x020 0x10000000 0x024 0 0x028 0x24B00000 0x02C 0
        0x030 0x27000000 0x034 0 0x038 0x02968F00 0x03C 0x00024C00
        0x040 0x001E6000 0x044 3}
    foreach {offset value} $config {
        m8_write_word [expr {$control_base + $offset}] $value
    }
    foreach {offset value} $config {
        m8_assert_word "CONFIG_[m8_word_hex $offset]" \
            [m8_read_word [expr {$control_base + $offset}]] $value
    }
    set global_reg_base [expr {$control_base + 0x080}]
    set layer_reg_base [expr {$control_base + 0x400}]
    for {set id 0} {$id < 200} {incr id} {
        set entry [expr {$table_base + 0x80 + $id * 0x40}]
        set offset [m8_read_words [expr {$entry + 0x10}] 2]
        if {[m8_word_u32 [lindex $offset 1]] != 0} {
            error "tensor $id offset exceeds 32 bits"
        }
        if {$id < 8} {
            set register [expr {$global_reg_base + 4 * $id}]
        } else {
            set register [expr {$layer_reg_base + 4 * ($id - 8)}]
        }
        m8_write_word $register [lindex $offset 0]
    }
    for {set id 0} {$id < 200} {incr id} {
        set expected [m8_read_word [expr {$table_base + 0x80 + $id * 0x40 + 0x10}]]
        if {$id < 8} {
            set register [expr {$global_reg_base + 4 * $id}]
        } else {
            set register [expr {$layer_reg_base + 4 * ($id - 8)}]
        }
        m8_assert_word "PARAM_$id" [m8_read_word $register] $expected
    }
    m8_write_word [expr {$control_base + 0x014}] 3
    m8_write_word [expr {$control_base + 0x008}] 8
    m8_write_word [expr {$control_base + 0x010}] 3
    m8_write_word [expr {$control_base + 0x0A0}] 0x1D85
    m8_write_word [expr {$control_base + 0x0A4}] 0
    m8_assert_word STATUS_READY [m8_read_word [expr {$control_base + 0x00C}]] 1
    m8_assert_word ERROR_CODE_READY [m8_read_word [expr {$control_base + 0x018}]] 0
    m8_assert_word ERROR_INFO_READY [m8_read_word [expr {$control_base + 0x01C}]] 0

    # These low DDR smoke-test locations are outside all M8 model/input/table/
    # scratch ranges and identify a retained session between XSCT processes.
    m8_write_word 0x01000000 $session_marker_0
    m8_write_word 0x01004000 $session_marker_1
    m8_assert_word SESSION_MARKER_0 [m8_read_word 0x01000000] $session_marker_0
    m8_assert_word SESSION_MARKER_1 [m8_read_word 0x01004000] $session_marker_1

    set setup_script [file normalize [info script]]
    set common_script [file join $script_dir m8_dataset_common.tcl]
    m8_write_record_exclusive $state_path [list \
        schema vit-m8-retained-ddr-session-v1 \
        status READY \
        created_utc [m8_utc_now] \
        profile [dict get $identity profile] \
        cable_serial $serial \
        identity_path $identity_path \
        identity_sha256 [m8_sha256_file $identity_path] \
        boot_receipt_path $boot_path \
        boot_receipt_sha256 [m8_sha256_file $boot_path] \
        bit_sha256 [dict get $identity bit_sha256] \
        xsa_sha256 [dict get $identity xsa_sha256] \
        model_path [lindex $model_spec 1] \
        model_sha256 [dict get $identity model_sha256] \
        table_path [lindex $table_spec 1] \
        table_sha256 [dict get $identity table_sha256] \
        scratch_zero_path $scratch_zero \
        scratch_zero_sha256 [lindex $zero_spec 3] \
        setup_tcl_sha256 [m8_sha256_file $setup_script] \
        common_tcl_sha256 [m8_sha256_file $common_script] \
        session_marker_0 [m8_word_hex $session_marker_0] \
        session_marker_1 [m8_word_hex $session_marker_1] \
        model_base 0x10000000 \
        input_base 0x24B00000 \
        table_base 0x25000000 \
        scratch_base 0x27000000 \
        execution_mode 3 \
        job_config 0x00001D85]
    m8_log {M8_DATASET_SESSION_READY model_load_count=1 inference_count=0}
} flow_error flow_options]

if {$force_mem_enabled} { catch {configparams force-mem-accesses 0} }
if {$connected} { catch {disconnect} }
if {$failed} {
    m8_log "M8_DATASET_COLD_INIT_FAIL=$flow_error"
    if {[dict exists $flow_options -errorinfo]} {
        puts stderr [dict get $flow_options -errorinfo]
    }
    exit 1
}
m8_log "M8_DATASET_COLD_INIT_PASS session_state=$state_path"
exit 0
