# M8 retained-DDR runner — mode 1/2/5/10

Trạng thái ngày 2026-08-10: code và host-only regression PASS; cold setup và
mode 5 vật lý cho các ảnh ILSVRC số 10..14 cũng PASS. Bộ công cụ không sửa
RTL, BIT, XSA, model package hay replay M8 một ảnh chuẩn.

## 1. Terminal hw_server

Giữ một terminal chạy:

```bash
/home/qh/Downloads/Vivado/Vivado/2023.2/bin/hw_server -s tcp::3121
```

Chỉ `hw_server` được chạy song song. Board lock sẽ từ chối nếu có hai setup/
test runner cùng lúc.

## 2. Preflight an toàn, không chạm JTAG

```bash
cd /home/qh/Downloads/vit_modelsim_standalone
tools/board/m8/dataset/setup_m8_session.sh --preflight-only
```

Phải thấy `jtag=NOT_TOUCHED`.

## 3. Setup board một lần sau mỗi lần bật/reset

Lệnh này có thao tác vật lý: system reset, PMUFW, BIT, FSBL, DDR smoke, nạp
model/table và cấu hình M8. Nó không START inference.

```bash
tools/board/m8/dataset/setup_m8_session.sh
```

Chỉ chạy lại setup nếu board mất điện, system/DDR reset, session marker hoặc
model sentinel sai. Model weight được DOW đúng một lần trong setup và được giữ
ở DDR cho mọi mode sau đó.

## 4. Chọn mode

Cách đơn giản nhất là gọi menu:

```bash
tools/board/m8/dataset/run_m8_dataset.sh
```

Runner sẽ hỏi mode `1`, `2`, `5` hoặc `10`, sau đó hỏi ảnh liên tiếp, chỉ số
rời rạc hay đường dẫn tùy ý.

Có thể dùng lệnh trực tiếp:

```bash
# Một ảnh tùy ý
tools/board/m8/dataset/run_1.sh --images /duong/dan/anh.jpg

# Hai ảnh ILSVRC đầu tiên
tools/board/m8/dataset/run_2.sh --start-index 1

# Hai chỉ số ILSVRC bất kỳ
tools/board/m8/dataset/run_2.sh --indices 1 50000

# Năm ảnh bất kỳ theo đường dẫn
tools/board/m8/dataset/run_5.sh --images a.jpg b.jpg c.jpg d.jpg e.jpg

# Mười ảnh liên tiếp từ ảnh 101
tools/board/m8/dataset/run_10.sh --start-index 101
```

Xem kế hoạch mà không preprocess, không XSCT và không chạm JTAG:

```bash
tools/board/m8/dataset/run_10.sh --start-index 101 --plan-only
```

## 5. Pipeline

Runner dùng đúng một preprocessing worker sống xuyên suốt batch. Sau khi input
ảnh hiện tại sẵn sàng, worker chuẩn bị ảnh kế tiếp trong lúc XSCT poll inference
ảnh hiện tại. Input kế tiếp chỉ được DOW vào `0x24B00000` sau DONE; không ghi đè
DDR input khi M8 còn BUSY.

Mỗi ảnh tạo một thư mục evidence dưới `build/m8_dataset_runs/`, gồm preprocess
manifest, input record, XSCT transcript, result record, counter CSV và mặc định
1,000 logits + 1,000 probabilities. `results.csv` và `progress.json` được cập
nhật atomically sau mỗi ảnh PASS.

## 6. Giới hạn hiện tại

- `gt_synset_id` được ghi đúng theo devkit cho ảnh ILSVRC.
- Exact `ILSVRC ID -> WNID -> model class index` chưa được tích hợp, vì vậy
  `expected_class_index` và `top1_correct` hiện để trống; không dùng
  `gt_synset_id - 1`.
- Runner dừng fail-closed tại ảnh đầu tiên lỗi. Checkpoint mỗi ảnh đã có;
  lệnh resume tự động chưa được hiện thực.
- Chỉ các mode 1/2/5/10 được nhận. Không có mode 50,000 trong bản này.

## 7. Host-only evidence đã PASS

- Identity + exact-XSA boot receipt preflight PASS, `jtag=NOT_TOUCHED`.
- 10/10 unit tests PASS.
- Mode 1/2/5/10 selection và cardinality fail-closed PASS.
- Tiền xử lý `inputs/test1.png` tái tạo bit-exact input SHA-256
  `3e13bd9bf60b07eb967a0c67aff1087954a316a403f70d220a6713cf8999ec54`,
  đúng 150,528 word / 602,112 byte.
