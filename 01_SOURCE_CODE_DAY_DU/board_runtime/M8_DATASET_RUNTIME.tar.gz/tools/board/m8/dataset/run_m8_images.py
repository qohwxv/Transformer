#!/usr/bin/env python3
"""Run mode 1/2/5/10/1000 on one prepared M8 retained-DDR session."""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import subprocess
import sys
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from m8_dataset_common import (
    DEFAULT_CONFIG,
    REPO_ROOT,
    SCRIPT_DIR,
    DatasetRunnerError,
    atomic_write_json,
    atomic_write_text,
    exclusive_board_lock,
    load_config,
    parse_record,
    relative_to_repo,
    resolve_repo_path,
    sha256_file,
    write_record_atomic,
)


ALLOWED_MODES = (1, 2, 5, 10, 1000)
RESULT_FIELDS = (
    "ordinal",
    "dataset_index",
    "source_image",
    "source_image_sha256",
    "prepared_input_sha256",
    "gt_synset_id",
    "expected_class_index",
    "predicted_class_index",
    "top1_correct",
    "class_logit",
    "class_probability",
    "job_cycles",
    "inference_elapsed_ms",
    "commands",
    "status_final",
    "error_code",
    "error_info",
    "status",
    "result_record",
)


@dataclass(frozen=True)
class ImageItem:
    ordinal: int
    path: str
    dataset_index: int | None
    gt_synset_id: int | None


def utc_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def prompt_mode() -> int:
    raw = input("Chọn mode số ảnh [1/2/5/10/1000]: ").strip()
    try:
        mode = int(raw)
    except ValueError as error:
        raise DatasetRunnerError("Mode phải là 1, 2, 5, 10 hoặc 1000") from error
    if mode not in ALLOWED_MODES:
        raise DatasetRunnerError("Mode phải là 1, 2, 5, 10 hoặc 1000")
    return mode


def prompt_selection(mode: int) -> tuple[str, list[str] | int]:
    print("Chọn nguồn ảnh:")
    print("  1: ảnh ILSVRC liên tiếp")
    print("  2: các chỉ số ILSVRC bất kỳ")
    print("  3: các đường dẫn ảnh bất kỳ")
    choice = input("Lựa chọn [1/2/3]: ").strip()
    if choice == "1":
        return "start", int(input("Chỉ số ảnh bắt đầu [1..50000]: ").strip())
    if choice == "2":
        values = input(f"Nhập đúng {mode} chỉ số, cách nhau bằng dấu cách: ").split()
        return "indices", values
    if choice == "3":
        values = [
            input(f"Đường dẫn ảnh {index}/{mode}: ").strip()
            for index in range(1, mode + 1)
        ]
        return "images", values
    raise DatasetRunnerError("Lựa chọn nguồn ảnh không hợp lệ")


def read_ground_truth(path: Path) -> list[int]:
    values = [int(line.strip()) for line in path.read_text(encoding="ascii").splitlines()]
    if len(values) != 50_000 or any(value < 1 or value > 1000 for value in values):
        raise DatasetRunnerError("Ground-truth file is not the exact 50,000-entry set")
    return values


def resolve_items(
    mode: int,
    config: dict[str, object],
    *,
    images: list[str] | None,
    indices: list[int] | None,
    start_index: int | None,
) -> list[ImageItem]:
    selected = sum(value is not None for value in (images, indices, start_index))
    if selected != 1:
        raise DatasetRunnerError(
            "Chọn đúng một kiểu: --images, --indices hoặc --start-index"
        )
    if start_index is not None:
        if start_index < 1 or start_index + mode - 1 > 50_000:
            raise DatasetRunnerError("Dải ảnh liên tiếp nằm ngoài 1..50000")
        indices = list(range(start_index, start_index + mode))
    if indices is not None:
        dataset_raw = Path(str(config["dataset_dir"]))
        dataset_dir = (
            dataset_raw if dataset_raw.is_absolute() else REPO_ROOT / dataset_raw
        ).resolve()
        ground_truth_raw = Path(str(config["ground_truth"]))
        ground_truth_path = (
            ground_truth_raw
            if ground_truth_raw.is_absolute()
            else REPO_ROOT / ground_truth_raw
        ).resolve()
        if not dataset_dir.is_dir():
            raise DatasetRunnerError(f"Dataset directory does not exist: {dataset_dir}")
        if not ground_truth_path.is_file():
            raise DatasetRunnerError(
                f"Ground-truth file does not exist: {ground_truth_path}"
            )
        ground_truth = read_ground_truth(ground_truth_path)
        if len(indices) != mode:
            raise DatasetRunnerError(f"Mode {mode} yêu cầu đúng {mode} chỉ số")
        if len(set(indices)) != len(indices):
            raise DatasetRunnerError("Danh sách chỉ số có phần tử trùng nhau")
        items = []
        for ordinal, index in enumerate(indices, 1):
            if index < 1 or index > 50_000:
                raise DatasetRunnerError(f"Chỉ số ngoài 1..50000: {index}")
            image = dataset_dir / f"ILSVRC2012_val_{index:08d}.JPEG"
            if not image.is_file():
                raise DatasetRunnerError(f"Ảnh dataset không tồn tại: {image}")
            items.append(
                ImageItem(
                    ordinal=ordinal,
                    path=str(image.resolve()),
                    dataset_index=index,
                    gt_synset_id=ground_truth[index - 1],
                )
            )
        return items

    assert images is not None
    if len(images) != mode:
        raise DatasetRunnerError(f"Mode {mode} yêu cầu đúng {mode} đường dẫn ảnh")
    resolved_images = [Path(value).expanduser().resolve() for value in images]
    if len(set(resolved_images)) != len(resolved_images):
        raise DatasetRunnerError("Danh sách ảnh có đường dẫn trùng nhau")
    items = []
    for ordinal, image in enumerate(resolved_images, 1):
        if not image.is_file():
            raise DatasetRunnerError(f"Ảnh không tồn tại: {image}")
        items.append(ImageItem(ordinal, str(image), None, None))
    return items


def resolve_session(config: dict[str, object], override: Path | None) -> Path:
    sessions_root = resolve_repo_path(str(config["sessions_root"]), must_exist=False)
    if override is not None:
        session_dir = override.resolve()
        try:
            session_dir.relative_to(REPO_ROOT)
        except ValueError as error:
            raise DatasetRunnerError("Session directory escapes repository") from error
    else:
        pointer = sessions_root / "current_session.json"
        if not pointer.is_file():
            raise DatasetRunnerError(
                "Chưa có current session; hãy chạy setup_m8_session.sh trước"
            )
        current = json.loads(pointer.read_text(encoding="utf-8"))
        if current.get("schema") != "vit-m8-current-retained-session-v1":
            raise DatasetRunnerError("Current session pointer has wrong schema")
        session_dir = resolve_repo_path(str(current["session_dir"]))
        state_path = session_dir / "session_state.txt"
        if sha256_file(state_path) != current.get("session_state_sha256"):
            raise DatasetRunnerError("Current session state hash changed")
    state_path = session_dir / "session_state.txt"
    state = parse_record(state_path)
    if state.get("schema") != "vit-m8-retained-ddr-session-v1" or state.get("status") != "READY":
        raise DatasetRunnerError("Selected session is not READY")
    return session_dir


def write_results_csv(path: Path, rows: list[dict[str, object]]) -> None:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=RESULT_FIELDS, lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow({field: row.get(field, "") for field in RESULT_FIELDS})
    atomic_write_text(path, stream.getvalue())


def stream_xsct(
    xsct: Path,
    tcl: Path,
    session_dir: Path,
    input_record: Path,
    image_dir: Path,
    transcript: Path,
    environment: dict[str, str],
) -> int:
    command = [
        str(xsct),
        str(tcl),
        str(REPO_ROOT),
        str(session_dir),
        str(input_record),
        str(image_dir),
    ]
    with transcript.open("x", encoding="utf-8", buffering=1) as log:
        process = subprocess.Popen(
            command,
            cwd=REPO_ROOT,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            log.write(line)
        return process.wait()


def input_record_from_manifest(manifest: dict[str, object], path: Path) -> None:
    source = manifest["source_image"]
    prepared = manifest["prepared_input"]
    assert isinstance(source, dict) and isinstance(prepared, dict)
    write_record_atomic(
        path,
        [
            ("schema", "vit-m8-dataset-input-v1"),
            ("image_ordinal", manifest["image_ordinal"]),
            ("source_image_path", source["path"]),
            ("source_image_sha256", source["sha256"]),
            ("prepared_input_path", prepared["path"]),
            ("prepared_input_size", prepared["size_bytes"]),
            ("prepared_input_sha256", prepared["sha256"]),
            ("first_word", prepared["first_word"]),
            ("last_word", prepared["last_word"]),
        ],
    )


def result_row(item: ImageItem, manifest: dict[str, object], record_path: Path) -> dict[str, object]:
    result = parse_record(record_path)
    if result.get("schema") != "vit-m8-dataset-image-result-v1" or result.get("status") != "PASS":
        raise DatasetRunnerError(f"Invalid image result record: {record_path}")
    source = manifest["source_image"]
    prepared = manifest["prepared_input"]
    assert isinstance(source, dict) and isinstance(prepared, dict)
    return {
        "ordinal": item.ordinal,
        "dataset_index": item.dataset_index or "",
        "source_image": source["path"],
        "source_image_sha256": source["sha256"],
        "prepared_input_sha256": prepared["sha256"],
        "gt_synset_id": item.gt_synset_id or "",
        # Exact WNID/model-index mapping is a separate fail-closed gate. Do not
        # silently use gt_synset_id - 1.
        "expected_class_index": "",
        "predicted_class_index": result["class_index"],
        "top1_correct": "",
        "class_logit": result["class_logit"],
        "class_probability": result["class_probability"],
        "job_cycles": result["job_cycles"],
        "inference_elapsed_ms": result["inference_elapsed_ms"],
        "commands": result["commands"],
        "status_final": result["status_final"],
        "error_code": result["error_code"],
        "error_info": result["error_info"],
        "status": "PASS",
        "result_record": relative_to_repo(record_path),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--mode", type=int, choices=ALLOWED_MODES)
    parser.add_argument("--images", nargs="+")
    parser.add_argument("--indices", nargs="+", type=int)
    parser.add_argument("--start-index", type=int)
    parser.add_argument("--session-dir", type=Path)
    parser.add_argument("--capture-outputs", choices=("all", "logits", "none"))
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)

    mode = args.mode
    if mode is None:
        if not sys.stdin.isatty():
            raise DatasetRunnerError("--mode is mandatory in non-interactive use")
        mode = prompt_mode()
    images = args.images
    indices = args.indices
    start_index = args.start_index
    if images is None and indices is None and start_index is None:
        if not sys.stdin.isatty():
            raise DatasetRunnerError("An image selection is mandatory")
        kind, value = prompt_selection(mode)
        if kind == "start":
            start_index = int(value)
        elif kind == "indices":
            assert isinstance(value, list)
            indices = [int(item) for item in value]
        else:
            assert isinstance(value, list)
            images = value
    items = resolve_items(
        mode,
        config,
        images=images,
        indices=indices,
        start_index=start_index,
    )
    plan = {"mode": mode, "count": len(items), "items": [asdict(item) for item in items]}
    if args.plan_only:
        print(json.dumps(plan, indent=2, ensure_ascii=False))
        print("M8_DATASET_PLAN_PASS jtag=NOT_TOUCHED")
        return 0

    session_dir = resolve_session(config, args.session_dir)
    xsct = Path(str(config["xsct"])).resolve()
    if not xsct.is_file() or not os.access(xsct, os.X_OK):
        raise DatasetRunnerError(f"XSCT is unavailable: {xsct}")
    runs_root = resolve_repo_path(str(config["runs_root"]), must_exist=False)
    runs_root.mkdir(parents=True, exist_ok=True)
    run_dir = runs_root / f"{utc_compact()}-m8-mode{mode}"
    if run_dir.exists():
        raise DatasetRunnerError(f"Run directory already exists: {run_dir}")

    capture_outputs = args.capture_outputs or str(config["capture_outputs"])
    tcl = SCRIPT_DIR / "run_one_retained_m8.tcl"
    session_state = session_dir / "session_state.txt"
    run_manifest = {
        "schema": "vit-m8-dataset-run-v1",
        "status": "RUNNING",
        "created_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "mode": mode,
        "count": len(items),
        "session_dir": relative_to_repo(session_dir),
        "session_state_sha256": sha256_file(session_state),
        "capture_outputs": capture_outputs,
        "pipeline": "one persistent host preprocess worker; queue depth one",
        "per_image_tcl_sha256": sha256_file(tcl),
        "items": [asdict(item) for item in items],
        "accuracy_status": "UNKNOWN_MODEL_CLASS_MAPPING_NOT_APPLIED",
    }

    rows: list[dict[str, object]] = []
    with exclusive_board_lock():
        run_dir.mkdir(mode=0o700)
        atomic_write_json(run_dir / "run_manifest.json", run_manifest)
        atomic_write_json(
            run_dir / "progress.json",
            {"status": "RUNNING", "completed": 0, "requested": mode},
        )
        from m8_preprocess import M8Preprocessor

        preprocessor = M8Preprocessor()
        environment = os.environ.copy()
        environment["VIT_HW_SERVER_URL"] = str(config["hw_server_url"])
        environment["VIT_POLL_MS"] = str(config["poll_ms"])
        environment["VIT_TIMEOUT_MS"] = str(config["timeout_ms"])
        environment["VIT_CAPTURE_OUTPUTS"] = capture_outputs
        with ThreadPoolExecutor(max_workers=1, thread_name_prefix="m8-preprocess") as executor:
            future: Future[dict[str, object]] = executor.submit(
                preprocessor.prepare,
                Path(items[0].path),
                run_dir / f"image_{items[0].ordinal:02d}",
                items[0].ordinal,
            )
            for position, item in enumerate(items):
                manifest = future.result()
                next_future: Future[dict[str, object]] | None = None
                if position + 1 < len(items):
                    next_item = items[position + 1]
                    next_future = executor.submit(
                        preprocessor.prepare,
                        Path(next_item.path),
                        run_dir / f"image_{next_item.ordinal:02d}",
                        next_item.ordinal,
                    )
                image_dir = run_dir / f"image_{item.ordinal:02d}"
                input_record = image_dir / "input_record.txt"
                input_record_from_manifest(manifest, input_record)
                transcript = image_dir / "xsct_transcript.log"
                print(
                    f"M8_DATASET_IMAGE_START ordinal={item.ordinal}/{mode} "
                    f"image={item.path}",
                    flush=True,
                )
                status = stream_xsct(
                    xsct,
                    tcl,
                    session_dir,
                    input_record,
                    image_dir,
                    transcript,
                    environment,
                )
                if status != 0:
                    atomic_write_json(
                        run_dir / "progress.json",
                        {
                            "status": "FAILED",
                            "completed": len(rows),
                            "requested": mode,
                            "failed_ordinal": item.ordinal,
                            "xsct_exit_status": status,
                        },
                    )
                    raise DatasetRunnerError(
                        f"Ảnh {item.ordinal} thất bại; evidence tại {image_dir}"
                    )
                record_path = image_dir / "m8_image_result.txt"
                row = result_row(item, manifest, record_path)
                rows.append(row)
                write_results_csv(run_dir / "results.csv", rows)
                atomic_write_json(
                    run_dir / "progress.json",
                    {
                        "status": "RUNNING" if len(rows) < mode else "PASS",
                        "completed": len(rows),
                        "requested": mode,
                        "last_completed_ordinal": item.ordinal,
                    },
                )
                print(
                    f"M8_DATASET_IMAGE_PASS ordinal={item.ordinal}/{mode} "
                    f"class_index={row['predicted_class_index']}",
                    flush=True,
                )
                if next_future is not None:
                    future = next_future

        run_manifest["status"] = "PASS"
        run_manifest["completed_utc"] = datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        run_manifest["completed"] = len(rows)
        atomic_write_json(run_dir / "run_manifest.json", run_manifest)
        evidence = sorted(path for path in run_dir.rglob("*") if path.is_file())
        sums = "".join(
            f"{sha256_file(path)}  {path.relative_to(run_dir).as_posix()}\n"
            for path in evidence
        )
        atomic_write_text(run_dir / "RUN_SHA256SUMS.txt", sums)

    print(f"M8_DATASET_MODE_PASS mode={mode} completed={len(rows)} run={run_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (DatasetRunnerError, ValueError, OSError, subprocess.SubprocessError) as error:
        print(f"M8_DATASET_RUN_FAIL: {error}", file=sys.stderr)
        raise SystemExit(1)
