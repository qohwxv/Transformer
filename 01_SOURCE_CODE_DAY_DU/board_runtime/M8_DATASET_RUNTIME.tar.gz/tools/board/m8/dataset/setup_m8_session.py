#!/usr/bin/env python3
"""Create one cold M8 retained-DDR session; never starts inference."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from m8_dataset_common import (
    DEFAULT_CONFIG,
    REPO_ROOT,
    SCRIPT_DIR,
    DatasetRunnerError,
    atomic_write_json,
    exclusive_board_lock,
    load_config,
    parse_record,
    relative_to_repo,
    resolve_repo_path,
    sha256_file,
)

sys.path.insert(0, str(REPO_ROOT))
from tools.board.m8 import m8_board_identity as identity_tool  # noqa: E402


SCRATCH_BYTES = 7_962_624
SCRATCH_SHA256 = "4cf5f204c0583a572fa4310cc7b737f8e9862f2975e592dc7ea5849208ee29df"


def utc_compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def validate_host(identity_path: Path, boot_path: Path) -> tuple[dict[str, str], dict[str, str]]:
    identity = identity_tool.validate_identity(REPO_ROOT, identity_path)
    boot = identity_tool.validate_boot_receipt(REPO_ROOT, identity, boot_path)
    return identity, boot


def stream_command(command: list[str], transcript: Path, environment: dict[str, str]) -> int:
    with transcript.open("x", encoding="utf-8", buffering=1) as log:
        process = subprocess.Popen(
            command,
            cwd=REPO_ROOT,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        assert process.stdout is not None
        for line in process.stdout:
            print(line, end="", flush=True)
            log.write(line)
        return process.wait()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--identity", type=Path)
    parser.add_argument("--boot-receipt", type=Path)
    parser.add_argument("--cable-serial")
    parser.add_argument("--xsct", type=Path)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()

    config = load_config(args.config)
    identity_path = (
        resolve_repo_path(str(args.identity))
        if args.identity
        else resolve_repo_path(str(config["identity"]))
    )
    boot_path = (
        resolve_repo_path(str(args.boot_receipt))
        if args.boot_receipt
        else resolve_repo_path(str(config["boot_receipt"]))
    )
    serial = (args.cable_serial or str(config["cable_serial"])).upper()
    xsct = (args.xsct.resolve() if args.xsct else Path(str(config["xsct"])).resolve())
    identity, boot = validate_host(identity_path, boot_path)
    if serial != str(config["cable_serial"]).upper():
        raise DatasetRunnerError("Cable override differs from audited config serial")
    print(
        "M8_DATASET_SESSION_PREFLIGHT_PASS "
        f"identity={sha256_file(identity_path)} boot={sha256_file(boot_path)} "
        "jtag=NOT_TOUCHED"
    )
    if args.preflight_only:
        return 0
    if not xsct.is_file() or not os.access(xsct, os.X_OK):
        raise DatasetRunnerError(f"XSCT is unavailable: {xsct}")

    sessions_root = resolve_repo_path(str(config["sessions_root"]), must_exist=False)
    sessions_root.mkdir(parents=True, exist_ok=True)
    with exclusive_board_lock():
        session_dir = sessions_root / f"{utc_compact()}-m8-retained-ddr"
        if session_dir.exists():
            raise DatasetRunnerError(f"Session directory already exists: {session_dir}")
        session_dir.mkdir(mode=0o700)
        scratch_zero = session_dir / "scratch_zero.bin"
        with scratch_zero.open("xb") as stream:
            stream.truncate(SCRATCH_BYTES)
            stream.flush()
            os.fsync(stream.fileno())
        if sha256_file(scratch_zero) != SCRATCH_SHA256:
            raise DatasetRunnerError("Scratch-zero file hash mismatch")

        tcl = SCRIPT_DIR / "cold_init_m8.tcl"
        transcript = session_dir / "cold_init_transcript.log"
        environment = os.environ.copy()
        environment["VIT_HW_SERVER_URL"] = str(config["hw_server_url"])
        command = [
            str(xsct),
            str(tcl),
            str(REPO_ROOT),
            str(session_dir),
            str(identity_path),
            str(boot_path),
            serial,
            str(scratch_zero),
        ]
        status = stream_command(command, transcript, environment)
        if status != 0:
            atomic_write_json(
                session_dir / "host_setup_status.json",
                {"status": "FAILED", "xsct_exit_status": status},
            )
            raise DatasetRunnerError(
                f"Cold setup failed; evidence retained at {session_dir}"
            )
        state_path = session_dir / "session_state.txt"
        state = parse_record(state_path)
        if state.get("status") != "READY":
            raise DatasetRunnerError("Cold setup returned without READY state")
        manifest = {
            "schema": "vit-m8-retained-ddr-host-session-v1",
            "status": "READY",
            "session_dir": relative_to_repo(session_dir),
            "session_state_sha256": sha256_file(state_path),
            "cold_transcript_sha256": sha256_file(transcript),
            "identity_sha256": sha256_file(identity_path),
            "boot_receipt_sha256": sha256_file(boot_path),
            "bit_sha256": identity["bit_sha256"],
            "xsa_sha256": identity["xsa_sha256"],
            "model_sha256": identity["model_sha256"],
            "table_sha256": identity["table_sha256"],
            "fsbl_sha256": boot["fsbl_sha256"],
            "pmufw_sha256": boot["pmufw_sha256"],
        }
        atomic_write_json(session_dir / "session_manifest.json", manifest)
        atomic_write_json(
            sessions_root / "current_session.json",
            {
                "schema": "vit-m8-current-retained-session-v1",
                "session_dir": relative_to_repo(session_dir),
                "session_state_sha256": manifest["session_state_sha256"],
            },
        )
    print(f"M8_DATASET_SESSION_SETUP_PASS session={session_dir}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (DatasetRunnerError, ValueError, OSError) as error:
        print(f"M8_DATASET_SESSION_SETUP_FAIL: {error}", file=sys.stderr)
        raise SystemExit(1)
