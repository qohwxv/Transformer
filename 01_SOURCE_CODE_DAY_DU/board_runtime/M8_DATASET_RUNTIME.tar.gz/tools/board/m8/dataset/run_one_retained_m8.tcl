# Run exactly one image using an already initialized M8 retained-DDR session.
# No system reset, BIT programming, PMUFW/FSBL download, or model/table DOW is
# permitted here.

if {[llength $argv] != 4} {
    puts stderr {Usage: xsct run_one_retained_m8.tcl <repo> <session-dir> <input-record> <result-dir>}
    exit 2
}

set repo_root [file normalize [lindex $argv 0]]
set session_dir [file normalize [lindex $argv 1]]
set input_record_path [file normalize [lindex $argv 2]]
set result_dir [file normalize [lindex $argv 3]]
set script_dir [file dirname [file normalize [info script]]]
source [file join $script_dir m8_dataset_common.tcl]

if {![file isdirectory $repo_root] || ![file isdirectory $session_dir] ||
    ![file isdirectory $result_dir]} {
    puts stderr {ERROR: invalid retained-run arguments}
    exit 2
}
set result_path [file join $result_dir m8_image_result.txt]
set failure_path [file join $result_dir m8_image_failure.txt]
if {[file exists $result_path] || [file exists $failure_path]} {
    puts stderr {ERROR: result/failure record already exists}
    exit 2
}

set state_path [file join $session_dir session_state.txt]
set state [m8_parse_record $state_path]
set input [m8_parse_record $input_record_path]
m8_require_record_keys $state {
    schema status cable_serial identity_path identity_sha256 boot_receipt_path
    boot_receipt_sha256 bit_sha256 xsa_sha256 model_path model_sha256
    table_path table_sha256 scratch_zero_path scratch_zero_sha256
    common_tcl_sha256 session_marker_0 session_marker_1 execution_mode job_config
} SESSION
m8_require_record_keys $input {
    schema image_ordinal source_image_path source_image_sha256
    prepared_input_path prepared_input_size prepared_input_sha256
    first_word last_word
} INPUT
if {[dict get $state schema] ne {vit-m8-retained-ddr-session-v1} ||
    [dict get $state status] ne {READY} ||
    [dict get $input schema] ne {vit-m8-dataset-input-v1}} {
    puts stderr {ERROR: session/input record schema or state mismatch}
    exit 2
}

set serial [string toupper [dict get $state cable_serial]]
set identity_path [m8_resolve_repo_artifact $repo_root [dict get $state identity_path]]
set boot_path [m8_resolve_repo_artifact $repo_root [dict get $state boot_receipt_path]]
set model_path [m8_resolve_repo_artifact $repo_root [dict get $state model_path]]
set table_path [m8_resolve_repo_artifact $repo_root [dict get $state table_path]]
set scratch_zero [m8_resolve_repo_artifact $repo_root [dict get $state scratch_zero_path]]
set input_bin [m8_resolve_repo_artifact $repo_root [dict get $input prepared_input_path]]
set common_script [file join $script_dir m8_dataset_common.tcl]

set connected 0
set force_mem_enabled 0
set control_base 0xA0000000
set model_base 0x10000000
set input_base 0x24B00000
set table_base 0x25000000
set scratch_base 0x27000000
set logits_base 0x27790000
set probabilities_base 0x27794000
set poll_ms 250
set timeout_ms 14400000
set capture_outputs all
if {[info exists ::env(VIT_POLL_MS)]} { set poll_ms $::env(VIT_POLL_MS) }
if {[info exists ::env(VIT_TIMEOUT_MS)]} { set timeout_ms $::env(VIT_TIMEOUT_MS) }
if {[info exists ::env(VIT_CAPTURE_OUTPUTS)]} { set capture_outputs $::env(VIT_CAPTURE_OUTPUTS) }
if {![string is integer -strict $poll_ms] || $poll_ms < 10 ||
    ![string is integer -strict $timeout_ms] || $timeout_ms <= 0 ||
    $capture_outputs ni {all logits none}} {
    puts stderr {ERROR: invalid poll/timeout/capture configuration}
    exit 2
}

set failed [catch {
    m8_validate_identity_before_jtag $repo_root $identity_path $boot_path
    if {[m8_sha256_file $identity_path] ne [dict get $state identity_sha256] ||
        [m8_sha256_file $boot_path] ne [dict get $state boot_receipt_sha256] ||
        [m8_sha256_file $common_script] ne [dict get $state common_tcl_sha256]} {
        error {session host identity/tool changed after cold initialization}
    }
    set model_spec [list MODEL $model_path 173685760 [dict get $state model_sha256]]
    set table_spec [list TABLE $table_path 12928 [dict get $state table_sha256]]
    set zero_spec [list SCRATCH_ZERO $scratch_zero 7962624 [dict get $state scratch_zero_sha256]]
    set input_spec [list INPUT $input_bin [dict get $input prepared_input_size] \
        [dict get $input prepared_input_sha256]]
    foreach spec [list $model_spec $table_spec $zero_spec $input_spec] {
        m8_verify_artifact $spec PRE_JTAG
    }
    if {[dict get $input prepared_input_size] != 602112} {
        error {prepared input is not exactly 602112 bytes}
    }
    m8_log "M8_RETAINED_IMAGE_PREFLIGHT_PASS ordinal=[dict get $input image_ordinal] jtag=NOT_YET_TOUCHED"

    if {[info exists ::env(VIT_HW_SERVER_URL)] && $::env(VIT_HW_SERVER_URL) ne {}} {
        connect -url $::env(VIT_HW_SERVER_URL)
    } else {
        connect
    }
    set connected 1
    set topology [m8_audit_live_topology $serial 1 RETAINED_IMAGE]
    m8_select_target $topology a53_0 {Cortex-A53 #0}
    configparams force-mem-accesses 1
    set force_mem_enabled 1

    set ddr_status [m8_read_word 0xFD070004]
    if {($ddr_status & 1) == 0} { error {DDR controller is not initialized} }
    m8_assert_word SESSION_MARKER_0 [m8_read_word 0x01000000] [dict get $state session_marker_0]
    m8_assert_word SESSION_MARKER_1 [m8_read_word 0x01004000] [dict get $state session_marker_1]
    m8_assert_word IP_ID [m8_read_word [expr {$control_base + 0x000}]] 0x5649544E
    m8_assert_word IP_VERSION [m8_read_word [expr {$control_base + 0x004}]] 0x0001000D
    set pre_status [m8_read_word [expr {$control_base + 0x00C}]]
    if {($pre_status & 1) == 0 || ($pre_status & 2) != 0 ||
        ($pre_status & 8) != 0} {
        error "NPU is not safely idle before image: STATUS=[m8_word_hex $pre_status]"
    }
    m8_assert_word MODEL_FIRST [m8_read_word $model_base] 0xA6FF2005
    m8_assert_word MODEL_LAST [m8_read_word 0x1A5A3BFC] 0x3E8209A8
    m8_assert_word TABLE_MAGIC [m8_read_word $table_base] 0x4D544956
    m8_assert_word TABLE_MODE [m8_read_word [expr {$table_base + 8}]] 3

    # Reset only the local M8 job state. DDR model/table remain retained.
    m8_write_word [expr {$control_base + 0x008}] 2
    after 50
    m8_write_word [expr {$control_base + 0x014}] 3
    after 10
    m8_assert_word STATUS_AFTER_SOFT_RESET [m8_read_word [expr {$control_base + 0x00C}]] 1
    m8_assert_word IRQ_AFTER_CLEAR [m8_read_word [expr {$control_base + 0x014}]] 0
    m8_assert_word ERROR_CODE_AFTER_RESET [m8_read_word [expr {$control_base + 0x018}]] 0
    m8_assert_word ERROR_INFO_AFTER_RESET [m8_read_word [expr {$control_base + 0x01C}]] 0

    m8_verify_artifact $input_spec IMMEDIATE_PRE_INPUT_DOW
    m8_log "LOAD_INPUT_START_UTC=[m8_utc_now]"
    dow -data $input_bin $input_base
    m8_log "LOAD_INPUT_DONE_UTC=[m8_utc_now]"
    m8_assert_word INPUT_FIRST [m8_read_word $input_base] [dict get $input first_word]
    m8_assert_word INPUT_LAST [m8_read_word 0x24B92FFC] [dict get $input last_word]

    m8_verify_artifact $zero_spec IMMEDIATE_PRE_SCRATCH_DOW
    m8_log "ZERO_SCRATCH_START_UTC=[m8_utc_now]"
    dow -data $scratch_zero $scratch_base
    m8_log "ZERO_SCRATCH_DONE_UTC=[m8_utc_now]"
    m8_assert_word SCRATCH_FIRST [m8_read_word $scratch_base] 0
    m8_assert_word SCRATCH_LAST [m8_read_word 0x27797FFC] 0

    set config {0x020 0x10000000 0x024 0 0x028 0x24B00000 0x02C 0
        0x030 0x27000000 0x034 0 0x038 0x02968F00 0x03C 0x00024C00
        0x040 0x001E6000 0x044 3}
    foreach {offset value} $config {
        m8_write_word [expr {$control_base + $offset}] $value
    }
    foreach {offset value} $config {
        m8_assert_word "CONFIG_[m8_word_hex $offset]" \
            [m8_read_word [expr {$control_base + $offset}]] $value
    }
    set global_reg_base [expr {$control_base + 0x080}]
    set layer_reg_base [expr {$control_base + 0x400}]
    for {set id 0} {$id < 200} {incr id} {
        set expected [m8_read_word [expr {$table_base + 0x80 + $id * 0x40 + 0x10}]]
        if {$id < 8} {
            set register [expr {$global_reg_base + 4 * $id}]
        } else {
            set register [expr {$layer_reg_base + 4 * ($id - 8)}]
        }
        m8_write_word $register $expected
        m8_assert_word "PARAM_$id" [m8_read_word $register] $expected
    }
    m8_write_word [expr {$control_base + 0x010}] 3
    m8_write_word [expr {$control_base + 0x0A0}] 0x1D85
    m8_write_word [expr {$control_base + 0x0A4}] 0
    m8_assert_word EXECUTION_MODE [m8_read_word [expr {$control_base + 0x044}]] 3
    m8_assert_word JOB_CONFIG [m8_read_word [expr {$control_base + 0x0A0}]] 0x1D85

    set start_utc [m8_utc_now]
    set start_ms [clock milliseconds]
    m8_log "INFERENCE_START_UTC=$start_utc"
    m8_write_word [expr {$control_base + 0x008}] 1
    set seen_busy 0
    set last -1
    set last_log $start_ms
    while {1} {
        set now [clock milliseconds]
        set elapsed [expr {$now - $start_ms}]
        set final [m8_read_word [expr {$control_base + 0x00C}]]
        if {$final != $last || $now - $last_log >= 60000} {
            m8_log "POLL elapsed_ms=$elapsed STATUS=[m8_word_hex $final]"
            set last $final
            set last_log $now
        }
        if {$final & 2} { set seen_busy 1 }
        if {$final & 8} {
            error "NPU ERROR status=[m8_word_hex $final] code=[m8_word_hex [m8_read_word [expr {$control_base+0x018}]]] info=[m8_word_hex [m8_read_word [expr {$control_base+0x01C}]]]"
        }
        if {$final & 4} {
            if {!$seen_busy} { error {DONE observed without BUSY witness} }
            break
        }
        if {$elapsed >= $timeout_ms} { error "inference timeout after $elapsed ms" }
        after $poll_ms
    }
    set done_ms [clock milliseconds]
    set done_utc [m8_utc_now]
    set elapsed_ms [expr {$done_ms - $start_ms}]
    m8_log "INFERENCE_DONE_UTC=$done_utc elapsed_ms=$elapsed_ms"
    m8_assert_word STATUS_FINAL $final 0x15
    set irq_final [m8_read_word [expr {$control_base + 0x014}]]
    set error_code [m8_read_word [expr {$control_base + 0x018}]]
    set error_info [m8_read_word [expr {$control_base + 0x01C}]]
    m8_assert_word IRQ_STATUS_FINAL $irq_final 1
    m8_assert_word ERROR_CODE_FINAL $error_code 0
    m8_assert_word ERROR_INFO_FINAL $error_info 0

    set perf_status [m8_read_word [expr {$control_base + 0x04C}]]
    if {($perf_status & 1) != 0 || ($perf_status & 2) == 0} {
        error "invalid PERF_STATUS=[m8_word_hex $perf_status]"
    }
    set job_cycles [m8_read_counter64 JOB_CYCLES [expr {$control_base + 0x050}]]
    set commands [m8_read_counter64 COMMANDS [expr {$control_base + 0x058}]]
    set axi_ar [m8_read_counter64 AXI_AR [expr {$control_base + 0x060}]]
    set axi_aw [m8_read_counter64 AXI_AW [expr {$control_base + 0x068}]]
    set stalls [m8_read_counter64 AXI_REQUEST_STALLS [expr {$control_base + 0x070}]]
    if {$commands != 249} { error "command count is $commands, expected 249" }
    set profile_status [m8_read_word [expr {$control_base + 0x18C}]]
    if {($profile_status & 0x0F) != 0} { error {profile status reports error/overflow} }
    foreach offset {0x190 0x194 0x198 0x19C 0x71C 0x724} {
        m8_assert_word "PROFILE_ZERO_[m8_word_hex $offset]" \
            [m8_read_word [expr {$control_base + $offset}]] 0
    }
    set m5_cap [m8_read_word [expr {$control_base + 0x7C0}]]
    set m5_status [m8_read_word [expr {$control_base + 0x7C4}]]
    set m5_overflow [m8_read_word [expr {$control_base + 0x7C8}]]
    set m5_protocol [m8_read_word [expr {$control_base + 0x7CC}]]
    m8_assert_word M5_CAPABILITY_FINAL $m5_cap 0x01F21008
    m8_assert_word M5_OVERFLOW_FINAL $m5_overflow 0
    m8_assert_word M5_PROTOCOL_FINAL $m5_protocol 0
    set m5_values {}
    for {set i 0} {$i < 8} {incr i} {
        lappend m5_values [m8_read_counter64 "M5_$i" [expr {$control_base + 0x7D0 + 8*$i}]]
    }
    if {[lindex $m5_values 4] != 0 || [lindex $m5_values 6] != 0 ||
        [lindex $m5_values 7] != 0 || [lindex $m5_values 5] > 2} {
        error {M5 native-AXI counter gate failed}
    }
    set m7_cap [m8_read_word [expr {$control_base + 0x810}]]
    set m7_status [m8_read_word [expr {$control_base + 0x814}]]
    set m7_ov_lo [m8_read_word [expr {$control_base + 0x818}]]
    set m7_ov_hi [m8_read_word [expr {$control_base + 0x81C}]]
    set m7_error [m8_read_word [expr {$control_base + 0x820}]]
    m8_assert_word M7_CAPABILITY_FINAL $m7_cap 0x01FF0817
    m8_assert_word M7_OVERFLOW_LO_FINAL $m7_ov_lo 0
    m8_assert_word M7_OVERFLOW_HI_FINAL $m7_ov_hi 0
    m8_assert_word M7_ERROR_FINAL $m7_error 0
    m8_write_m7_csv [file join $result_dir m7_overlap_counters.csv] $control_base

    set class_index [m8_read_word [expr {$control_base + 0x180}]]
    if {$class_index < 0 || $class_index >= 1000} {
        error "class index outside 0..999: $class_index"
    }
    set class_logit [m8_read_word [expr {$control_base + 0x184}]]
    m8_assert_word CLASS_LOGIT_DDR \
        [m8_read_word [expr {$logits_base + 4*$class_index}]] $class_logit
    set class_probability [m8_read_word [expr {$probabilities_base + 4*$class_index}]]
    m8_log "RESULT class_index=$class_index class_logit=[m8_word_hex $class_logit] class_probability=[m8_word_hex $class_probability]"

    set logits_sha NOT_CAPTURED
    set probabilities_sha NOT_CAPTURED
    if {$capture_outputs in {all logits}} {
        set logits [file join $result_dir board_logits_f32.hex]
        m8_dump_words_hex $logits $logits_base 1000
        set logits_sha [m8_sha256_file $logits]
    }
    if {$capture_outputs eq {all}} {
        set probabilities [file join $result_dir board_probabilities_f32.hex]
        m8_dump_words_hex $probabilities $probabilities_base 1000
        set probabilities_sha [m8_sha256_file $probabilities]
    }

    m8_write_record_exclusive $result_path [list \
        schema vit-m8-dataset-image-result-v1 \
        status PASS \
        image_ordinal [dict get $input image_ordinal] \
        source_image_path [dict get $input source_image_path] \
        source_image_sha256 [dict get $input source_image_sha256] \
        prepared_input_sha256 [dict get $input prepared_input_sha256] \
        session_state_sha256 [m8_sha256_file $state_path] \
        start_utc $start_utc \
        done_utc $done_utc \
        inference_elapsed_ms $elapsed_ms \
        status_final [m8_word_hex $final] \
        irq_status_final [m8_word_hex $irq_final] \
        error_code [m8_word_hex $error_code] \
        error_info [m8_word_hex $error_info] \
        job_cycles $job_cycles \
        commands $commands \
        axi_ar $axi_ar \
        axi_aw $axi_aw \
        axi_request_stalls $stalls \
        m5_status [m8_word_hex $m5_status] \
        m7_status [m8_word_hex $m7_status] \
        class_index $class_index \
        class_logit [m8_word_hex $class_logit] \
        class_probability [m8_word_hex $class_probability] \
        capture_outputs $capture_outputs \
        logits_sha256 $logits_sha \
        probabilities_sha256 $probabilities_sha \
        per_image_tcl_sha256 [m8_sha256_file [file normalize [info script]]]]
    m8_log "M8_RETAINED_IMAGE_PASS ordinal=[dict get $input image_ordinal] class_index=$class_index"
} flow_error flow_options]

if {$force_mem_enabled} { catch {configparams force-mem-accesses 0} }
if {$connected} { catch {disconnect} }
if {$failed} {
    set clean_error [string map [list "\n" { } "\r" { } "=" {:}] $flow_error]
    catch {
        m8_write_record_exclusive $failure_path [list \
            schema vit-m8-dataset-image-failure-v1 \
            status FAILED \
            failed_utc [m8_utc_now] \
            image_ordinal [dict get $input image_ordinal] \
            error $clean_error]
    }
    m8_log "M8_RETAINED_IMAGE_FAIL=$flow_error"
    if {[dict exists $flow_options -errorinfo]} {
        puts stderr [dict get $flow_options -errorinfo]
    }
    exit 1
}
exit 0
