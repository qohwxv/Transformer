#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import sys
import unittest
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
REPO = SCRIPT_DIR.parents[3]
sys.path.insert(0, str(SCRIPT_DIR))

from m8_dataset_common import DEFAULT_CONFIG, DatasetRunnerError, load_config  # noqa: E402
from run_m8_images import ALLOWED_MODES, resolve_items  # noqa: E402


class DatasetModeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(DEFAULT_CONFIG)

    def test_consecutive_mode_two(self) -> None:
        items = resolve_items(
            2, self.config, images=None, indices=None, start_index=1
        )
        self.assertEqual([item.dataset_index for item in items], [1, 2])
        self.assertEqual([item.gt_synset_id for item in items], [490, 361])
        self.assertTrue(items[0].path.endswith("ILSVRC2012_val_00000001.JPEG"))

    def test_sparse_mode_five(self) -> None:
        wanted = [1, 17, 105, 900, 50000]
        items = resolve_items(
            5, self.config, images=None, indices=wanted, start_index=None
        )
        self.assertEqual([item.dataset_index for item in items], wanted)

    def test_wrong_cardinality_fails(self) -> None:
        with self.assertRaisesRegex(DatasetRunnerError, "đúng 2"):
            resolve_items(
                2, self.config, images=None, indices=[1], start_index=None
            )

    def test_duplicate_indices_fail(self) -> None:
        with self.assertRaisesRegex(DatasetRunnerError, "trùng"):
            resolve_items(
                2, self.config, images=None, indices=[1, 1], start_index=None
            )

    def test_plan_only_never_needs_a_session(self) -> None:
        command = [
            str(SCRIPT_DIR / "run_2.sh"),
            "--start-index",
            "1",
            "--plan-only",
        ]
        result = subprocess.run(
            command, cwd=REPO, text=True, capture_output=True, check=False
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("M8_DATASET_PLAN_PASS jtag=NOT_TOUCHED", result.stdout)

    def test_custom_image_does_not_require_ilsvrc_dataset(self) -> None:
        config = dict(self.config)
        config["dataset_dir"] = "path/that/does/not/exist"
        config["ground_truth"] = "path/that/does/not/exist.txt"
        image = REPO / "inputs/test1.png"
        items = resolve_items(
            1, config, images=[str(image)], indices=None, start_index=None
        )
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0].path, str(image.resolve()))
        self.assertIsNone(items[0].dataset_index)

    def test_mode_1000_is_explicitly_enabled(self) -> None:
        self.assertEqual(ALLOWED_MODES, (1, 2, 5, 10, 1000))


class HardwareBoundaryTests(unittest.TestCase):
    def test_cold_setup_and_per_image_boundaries(self) -> None:
        cold = (SCRIPT_DIR / "cold_init_m8.tcl").read_text(encoding="utf-8")
        one = (SCRIPT_DIR / "run_one_retained_m8.tcl").read_text(encoding="utf-8")
        for required in (
            "rst -system",
            "fpga -file",
            "dow $pmufw_path",
            "dow $fsbl_path",
            "LOAD_MODEL_START_UTC",
        ):
            self.assertIn(required, cold)
            self.assertNotIn(required, one)
        self.assertNotIn("INFERENCE_START_UTC", cold)
        self.assertIn("INFERENCE_START_UTC", one)
        self.assertIn("[expr {$control_base + 0x008}] 2", one)
        self.assertIn("[expr {$control_base + 0x008}] 1", one)

    def test_no_persistent_flash_command(self) -> None:
        combined = "\n".join(
            path.read_text(encoding="utf-8")
            for path in SCRIPT_DIR.iterdir()
            if path.suffix in {".py", ".sh", ".tcl"}
            and not path.name.startswith("test_")
        ).lower()
        for forbidden in ("program_flash", "flashwriter", "bootgen -image"):
            self.assertNotIn(forbidden, combined)

    def test_preflight_precedes_connect(self) -> None:
        for name in ("cold_init_m8.tcl", "run_one_retained_m8.tcl"):
            text = (SCRIPT_DIR / name).read_text(encoding="utf-8")
            validator = text.index("m8_validate_identity_before_jtag")
            connect = text.index("connect -url", validator)
            self.assertLess(validator, connect)

    def test_pipeline_submits_next_before_xsct(self) -> None:
        text = (SCRIPT_DIR / "run_m8_images.py").read_text(encoding="utf-8")
        loop = text.index("for position, item in enumerate(items):")
        submit = text.index("next_future = executor.submit", loop)
        xsct = text.index("status = stream_xsct", loop)
        self.assertLess(submit, xsct)

    def test_mode_wrappers_are_thin(self) -> None:
        for mode in (1, 2, 5, 10, 1000):
            text = (SCRIPT_DIR / f"run_{mode}.sh").read_text(encoding="utf-8")
            self.assertIn(f"--mode {mode}", text)
            self.assertIn("run_m8_dataset.sh", text)
            self.assertNotIn("xsct", text.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
