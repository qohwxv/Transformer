#!/usr/bin/env python3
"""Generate a concrete portable M8 dataset-runner configuration."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

from m8_dataset_common import (
    DEFAULT_CONFIG,
    REPO_ROOT,
    DatasetRunnerError,
    atomic_write_json,
    relative_to_repo,
)

sys.path.insert(0, str(REPO_ROOT))
from tools.board.m8 import m8_board_identity as identity_tool  # noqa: E402


SERIAL_RE = re.compile(r"^[0-9A-Fa-f]{8,32}$")


def repo_path(value: Path, label: str) -> Path:
    resolved = value.expanduser().resolve()
    try:
        resolved.relative_to(REPO_ROOT)
    except ValueError as error:
        raise DatasetRunnerError(f"{label} must be inside {REPO_ROOT}") from error
    if not resolved.exists():
        raise DatasetRunnerError(f"{label} does not exist: {resolved}")
    return resolved


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xsct", type=Path, required=True)
    parser.add_argument("--cable-serial", required=True)
    parser.add_argument(
        "--identity",
        type=Path,
        default=REPO_ROOT / "build/board_identities/m8/m8_v3_mode3_50mhz.identity",
    )
    parser.add_argument(
        "--boot-receipt",
        type=Path,
        default=REPO_ROOT / "build/board_boot/m8_20260810_run1/m8_boot_receipt.txt",
    )
    parser.add_argument("--hw-server-url", default="tcp:127.0.0.1:3121")
    parser.add_argument("--dataset-dir", default="datasets/ILSVRC2012_img_val")
    parser.add_argument(
        "--ground-truth",
        default="build/m8_imagenet_reference/devkit/ILSVRC2012_validation_ground_truth.txt",
    )
    parser.add_argument("--poll-ms", type=int, default=250)
    parser.add_argument("--timeout-ms", type=int, default=14_400_000)
    parser.add_argument("--capture-outputs", choices=("all", "logits", "none"), default="all")
    parser.add_argument("--output", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    xsct = args.xsct.expanduser().resolve()
    if not xsct.is_file() or not os.access(xsct, os.X_OK):
        raise DatasetRunnerError(f"XSCT is not executable: {xsct}")
    serial = args.cable_serial.upper()
    if not SERIAL_RE.fullmatch(serial):
        raise DatasetRunnerError("Cable serial must be 8..32 hexadecimal characters")
    identity_path = repo_path(args.identity, "Identity")
    boot_path = repo_path(args.boot_receipt, "Boot receipt")
    identity = identity_tool.validate_identity(REPO_ROOT, identity_path)
    identity_tool.validate_boot_receipt(REPO_ROOT, identity, boot_path)
    output = args.output.expanduser().resolve()
    try:
        output.relative_to(REPO_ROOT)
    except ValueError as error:
        raise DatasetRunnerError("Output config must remain inside the workspace") from error
    if output.exists() and not args.force:
        raise DatasetRunnerError(f"Config already exists; use --force: {output}")
    if args.poll_ms < 10 or args.timeout_ms <= 0:
        raise DatasetRunnerError("Invalid poll/timeout value")

    config = {
        "schema": "vit-m8-dataset-session-config-v1",
        "identity": relative_to_repo(identity_path),
        "boot_receipt": relative_to_repo(boot_path),
        "cable_serial": serial,
        "xsct": str(xsct),
        "hw_server_url": args.hw_server_url,
        "sessions_root": "build/m8_dataset_sessions",
        "runs_root": "build/m8_dataset_runs",
        "dataset_dir": args.dataset_dir,
        "ground_truth": args.ground_truth,
        "poll_ms": args.poll_ms,
        "timeout_ms": args.timeout_ms,
        "capture_outputs": args.capture_outputs,
    }
    atomic_write_json(output, config)
    print(
        "M8_PORTABLE_CONFIG_PASS "
        f"config={output} serial={serial} xsct={xsct} "
        f"identity={identity_path} boot={boot_path}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (DatasetRunnerError, ValueError, OSError, json.JSONDecodeError) as error:
        print(f"M8_PORTABLE_CONFIG_FAIL: {error}", file=sys.stderr)
        raise SystemExit(1)
