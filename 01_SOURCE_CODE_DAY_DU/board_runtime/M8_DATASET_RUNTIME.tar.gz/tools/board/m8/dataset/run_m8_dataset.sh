#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd -- "${script_dir}/../../../.." && pwd)"
python_bin="${VIT_PYTHON:-${repo_root}/.venv/bin/python}"
exec "${python_bin}" "${script_dir}/run_m8_images.py" "$@"
