# Synthesizable ViT NPU with AXI and the Vivado IP-Integrator shim.
# Compile from repository root. Order: packages -> leaf -> blocks -> core -> AXI -> top.
rtl/pkg/vit_phase_e_pkg.sv
rtl/pkg/vit_fp32_pkg.sv

rtl/leaf/common/vit_counter.sv
rtl/leaf/common/vit_lane_mask.sv
rtl/leaf/common/vit_stream_buffer.sv
rtl/leaf/common/vit_u32_mul_iterative_nodsp.sv

rtl/leaf/fp32/vit_fp32_add_comb.sv
rtl/leaf/fp32/vit_fp32_sub_comb.sv
rtl/leaf/fp32/vit_fp32_compare.sv
rtl/leaf/fp32/vit_fp32_mul_comb_nodsp.sv
rtl/leaf/fp32/vit_fp32_accumulator.sv
rtl/leaf/fp32/vit_fp32_from_u32_comb.sv
rtl/leaf/fp32/vit_fp32_to_u32_floor_comb.sv
rtl/leaf/fp32/vit_fp32_scale_pow2_down_comb.sv
rtl/leaf/fp32/vit_fp32_recip_u32_comb.sv
rtl/leaf/fp32/vit_fp32_recip_u32_serial.sv
rtl/leaf/fp32/vit_fp32_recip_comb.sv
rtl/leaf/fp32/vit_fp32_rsqrt_step_comb.sv
rtl/leaf/fp32/vit_fp32_exp_neg_comb.sv
rtl/leaf/fp32/vit_fp32_gelu_comb.sv

rtl/leaf/fp16/vit_fp32_to_fp16_rne_gradual.sv
rtl/leaf/fp16/vit_fp16_mul_to_fp32_comb_nodsp.sv
rtl/leaf/fp16/vit_fp32_product_to_fixed_exact.sv
rtl/leaf/fp16/vit_fixed_analyze.sv
rtl/leaf/fp16/vit_fixed_normalized_to_fp32_rne.sv
rtl/leaf/fp16/vit_fixed_to_fp32_rne.sv
rtl/leaf/fp16/vit_fp16_dot_stream_csa_nodsp.sv

rtl/blocks/gemm/vit_gemm_controller.sv
rtl/blocks/gemm/vit_gemm_operand_router.sv
rtl/blocks/gemm/vit_gemm_result_path.sv
rtl/blocks/gemm/vit_fp32_reduce16.sv
rtl/blocks/gemm/vit_gemm_dot16.sv
rtl/blocks/gemm/vit_gemm_dot16_serial.sv
rtl/blocks/gemm/vit_gemm_accumulator.sv
rtl/blocks/gemm/vit_gemm_accumulator_bank.sv
rtl/blocks/gemm/vit_gemm_pe.sv
rtl/blocks/gemm/vit_gemm_pe_array.sv
rtl/blocks/gemm/vit_tree_pe_fp32.sv
rtl/blocks/gemm/vit_gemm_tree_array.sv
rtl/blocks/gemm/vit_gemm_activation_panel_cache.sv
rtl/blocks/gemm/vit_gemm_bias_cache.sv
rtl/blocks/gemm/vit_gemm_fp16_stream_array.sv
rtl/blocks/gemm/vit_gemm_result_fifo.sv
rtl/blocks/gemm/vit_gemm_fp16_parallel_scheduler.sv
rtl/blocks/gemm/vit_gemm_dual_mode_array.sv

rtl/blocks/vector/vit_vector_lane_alu.sv
rtl/blocks/vector/vit_vector_datapath.sv
rtl/blocks/vector/vit_vector_engine_fp32.sv

rtl/blocks/layout/vit_layout_address_generator.sv
rtl/blocks/layout/vit_layout_descriptor_validator.sv
rtl/blocks/layout/vit_layout_engine.sv

rtl/blocks/layernorm/vit_layernorm_statistics_datapath.sv
rtl/blocks/layernorm/vit_layernorm_affine_datapath.sv
rtl/blocks/layernorm/vit_layernorm_engine_fp32.sv

rtl/blocks/softmax/vit_softmax_exp_datapath.sv
rtl/blocks/softmax/vit_softmax_reciprocal_step.sv
rtl/blocks/softmax/vit_softmax_engine_fp32.sv

rtl/blocks/gelu/vit_gelu_lane_datapath.sv
rtl/blocks/gelu/vit_fp32_gelu_serial.sv
rtl/blocks/gelu/vit_gelu_engine_fp32.sv

rtl/blocks/argmax/vit_argmax_engine_fp32.sv

rtl/control/vit_phase_e_sequencer.sv
rtl/core/vit_gemm_memory_address_context.sv
rtl/core/vit_phase_e_read_address_router.sv
rtl/core/vit_phase_e_write_address_router.sv
rtl/core/vit_phase_e_memory_frontend.sv
rtl/core/vit_phase_e_command_controller.sv
rtl/core/vit_phase_e_engine_dispatch.sv
rtl/core/vit_phase_e_engine_top.sv
rtl/core/vit_phase_e_npu.sv

rtl/axi/control/vit_layer_param_table.sv
rtl/axi/control/vit_layer_param_loader.sv
rtl/axi/control/vit_phase_e_perf_counters.sv
rtl/axi/control/vit_phase_e_profile_counters.sv
rtl/axi/control/vit_phase_e_m5_axi_counters.sv
rtl/axi/control/vit_phase_e_m7_overlap_counters.sv
rtl/axi/control/vit_axi_lite_control_regs.sv
rtl/axi/memory/vit_phase_e_axi_mem_adapter.sv
rtl/axi/vit_phase_e_axi_wrapper.sv
rtl/top/vit_phase_e_axi_bd_wrapper.v
